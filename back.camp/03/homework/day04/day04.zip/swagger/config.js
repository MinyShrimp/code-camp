
const config = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: "나만의 미니프로젝트 API 명세서",
            version: "v0.0.1"
        },
    },
    apis: ['./swagger/*.swagger.js']
}

export default config;